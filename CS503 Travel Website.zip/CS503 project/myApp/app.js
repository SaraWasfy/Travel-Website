var express = require('express');
var path = require('path');
var sessions = require('express-session');
const cookieParser = require("cookie-parser");

var app = express();


var { MongoClient }= require("mongodb");
const { equal } = require('assert');
const { isNull } = require('util');
const { validateHeaderName } = require('http');
// Connection URI
var uri = "mongodb://0.0.0.0:27017";
// Create a new MongoClient
var client = new MongoClient(uri);
var col = client.db("myDB").collection("myCollection");

const oneDay = 1000 * 60 * 60 * 24;



// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(cookieParser());
app.use(sessions({
  secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
  saveUninitialized:true,
  cookie: { maxAge: oneDay },
  resave: false 
}));
var session;

app.get('/', function(req, res){
  req.session.destroy();
  session = req.session;
  res.render('login', {errormsg: ""})
});
app.get('/annapurna', function(req, res){
  if(session.userid)
  res.render('annapurna', {errormsg: ""})
});
app.get('/bali', function(req, res){
  if(session.userid)
  res.render('bali', {errormsg: ""})
});
app.get('/cities', function(req, res){
  if(session.userid)
  res.render('cities')
});
app.get('/hiking', function(req, res){
  if(session.userid)
  res.render('hiking')
});
app.get('/home', function(req, res){
  if(session.userid)
  res.render('home')
});
app.get('/inca', function(req, res){
  if(session.userid)
  res.render('inca', {errormsg: ""})
});
app.get('/islands', function(req, res){
  if(session.userid)
  res.render('islands')
});
app.get('/paris', function(req, res){
  if(session.userid)
  res.render('paris', {errormsg: ""})
});
app.get('/registration', function(req, res){
  res.render('registration', {errormsg: ""})
});
app.get('/rome', function(req, res){
  if(session.userid)
  res.render('rome', {errormsg: ""})
});
app.get('/santorini', function(req, res){
  if(session.userid)
  res.render('santorini', {errormsg: ""})
});
/*app.get('/searchresults', function(req, res){
  res.render('searchresults')
});*/
app.get('/wanttogo', async function(req, res){
  if(session.userid){
    var list = Array(7);
    var i = 0;
    var names = ["annapurna", "bali", "inca", "paris", "rome", "santorini"];
    for(var j=0; j<6; j++){
      if(await col.findOne({name: req.session.userid, wanttogo: names[j]})){
        list[i] = names[j];
        i++;
      }
    }
    if(i==0){
      list[6] = "Want to go list empty";
    }
    res.render('wanttogo', {List: list})
}
});


app.post('/search', function(req,res){
  var Search = req.body.Search;
  var list = Array(7);
  var i = 0;
  var names = ["annapurna", "bali", "inca", "paris", "rome", "santorini"];
  if(Search){
  for(var j=0; j<6; j++){
    var b = names[j].includes(Search);
    if(b){
      list[i] = names[j];
      i++;
    }
  }
  if(i==0)list[6]="Destination not Found";
  res.render('searchresults', {List: list})}
});



app.post('/register', async function(req,res){
  if(req.body.username && req.body.password){
  var sth;
  sth = await col.findOne({name: req.body.username});
    if(sth){
    res.render('registration', {errormsg: "Username already exists"});
  }
  else{
    col.insertOne({name: req.body.username, password: req.body.password, wanttogo: [""]});
    res._destroy;
    res.render('login', {errormsg: "Registration successful"});
  }}else{
    res.render('registration', {errormsg: "Must enter username and password"});
  }
});

app.post('/login', async function(req,res){
  if(req.body.username && req.body.password){
  var sth;
  sth = await col.findOne({name: req.body.username, password: req.body.password});
    if(!sth){
    res.render('login', {errormsg: "Wrong username or password"});
  }
  else{
    session=req.session;
    session.userid=req.body.username;
    res.render('home');
  }}else{
    res.render('login', {errormsg: "Must enter username and password"});
  }
});


app.post('/annapurna', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "annapurna"});
  if(userwant){
    res.render('annapurna', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "annapurna"}});
    res.render('annapurna', {errormsg: "Added successfully"});
  }
});


app.post('/bali', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "bali"});
  if(userwant){
    res.render('bali', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "bali"}});
    res.render('bali', {errormsg: "Added successfully"});
  }
});


app.post('/inca', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "inca"});
  if(userwant){
    res.render('inca', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "inca"}});
    res.render('inca', {errormsg: "Added successfully"});
  }
});


app.post('/paris', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "paris"});
  if(userwant){
    res.render('paris', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "paris"}});
    res.render('paris', {errormsg: "Added successfully"});
  }
});


app.post('/rome', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "rome"});
  if(userwant){
    res.render('rome', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "rome"}});
    res.render('rome', {errormsg: "Added successfully"});
  }
});


app.post('/santorini', async function(req,res){
  var userwant = await col.findOne({name: req.session.userid, wanttogo: "santorini"});
  if(userwant){
    res.render('santorini', {errormsg: "Already in want to go list"});
  }
  else{
    col.updateOne( {name: req.session.userid}, {$push: {wanttogo: "santorini"}});
    res.render('santorini', {errormsg: "Added successfully"});
  }
});




app.listen(3000);
